/* Панель доступності ІГС. Розробка: OLBO. */
(function () {
	var KEY = 'igs_a11y';
	var root = document.documentElement;
	var en = (root.getAttribute('lang') || '').indexOf('en') === 0;
	var defaults = { size: '0', theme: 'default', font: 'default' };
	var pl = (root.getAttribute('lang') || '').indexOf('pl') === 0;
	var names = pl
		? { size: { '-1': 'mniejszy tekst', '0': 'standardowy rozmiar', '1': 'większy tekst', '2': 'duży tekst', '3': 'największy tekst' }, theme: { 'default': 'motyw dzienny', soft: 'łagodny motyw dzienny', night: 'motyw nocny', contrast: 'wysoki kontrast' }, font: { 'default': 'standardowa czcionka', sans: 'czcionka bezszeryfowa', dyslexia: 'czcionka dla osób z dysleksją' }, on: 'Włączono: ', reset: 'Ustawienia przywrócone' }
		: en
		? { size: { '-1': 'smaller text', '0': 'standard size', '1': 'larger text', '2': 'large text', '3': 'largest text' }, theme: { 'default': 'day theme', soft: 'soft daylight theme', night: 'night theme', contrast: 'high contrast' }, font: { 'default': 'standard font', sans: 'sans-serif font', dyslexia: 'dyslexia-friendly font' }, on: 'Enabled: ', reset: 'Settings reset' }
		: { size: { '-1': 'менший текст', '0': 'звичайний розмір', '1': 'більший текст', '2': 'великий текст', '3': 'найбільший текст' }, theme: { 'default': 'денна тема', soft: 'ніжна денна тема', night: 'нічна тема', contrast: 'висока контрастність' }, font: { 'default': 'стандартний шрифт', sans: 'шрифт без засічок', dyslexia: 'шрифт для людей з дислексією' }, on: 'Увімкнено: ', reset: 'Налаштування скинуто' };

	function load() {
		try { var s = JSON.parse(localStorage.getItem(KEY) || '{}'); return { size: s.size || defaults.size, theme: s.theme || defaults.theme, font: s.font || defaults.font }; }
		catch (e) { return { size: defaults.size, theme: defaults.theme, font: defaults.font }; }
	}
	function save(s) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) {} }

	var state = load();

	function apply() {
		['size', 'theme', 'font'].forEach(function (k) {
			if (state[k] === defaults[k]) { root.removeAttribute('data-' + k); } else { root.setAttribute('data-' + k, state[k]); }
		});
		var opts = document.querySelectorAll('.igs-a11y__opt');
		for (var i = 0; i < opts.length; i++) {
			var b = opts[i];
			b.setAttribute('aria-pressed', state[b.getAttribute('data-k')] === b.getAttribute('data-v') ? 'true' : 'false');
		}
		var dn = document.querySelector('.igs-daynight');
		if (dn) { dn.setAttribute('aria-pressed', state.theme === 'night' ? 'true' : 'false'); }
	}

	function init() {
		var wrap = document.querySelector('.igs-a11y');
		if (!wrap) { return; }
		var btn = wrap.querySelector('.igs-a11y__btn');
		var panel = wrap.querySelector('.igs-a11y__panel');
		var status = wrap.querySelector('.igs-a11y__status');

		function open() { panel.hidden = false; btn.setAttribute('aria-expanded', 'true'); var f = panel.querySelector('[aria-pressed="true"]') || panel.querySelector('button'); if (f) { f.focus(); } }
		function close(returnFocus) { panel.hidden = true; btn.setAttribute('aria-expanded', 'false'); if (returnFocus) { btn.focus(); } }

		btn.addEventListener('click', function () { if (panel.hidden) { open(); } else { close(false); } });
		wrap.querySelector('.igs-a11y__close').addEventListener('click', function () { close(true); });

		panel.addEventListener('click', function (e) {
			var b = e.target.closest('.igs-a11y__opt');
			if (b) {
				var k = b.getAttribute('data-k'), v = b.getAttribute('data-v');
				state[k] = v; save(state); apply();
				var label = names[k][v];
				status.textContent = names.on + label;
				return;
			}
			if (e.target.closest('.igs-a11y__reset')) {
				state = { size: defaults.size, theme: defaults.theme, font: defaults.font };
				save(state); apply(); status.textContent = names.reset;
			}
		});

		var dnb = document.querySelector('.igs-daynight');
		if (dnb) {
			dnb.addEventListener('click', function () {
				state.theme = state.theme === 'night' ? 'default' : 'night';
				save(state); apply();
				status.textContent = names.on + names.theme[state.theme];
			});
		}

		document.addEventListener('keydown', function (e) { if ((e.key === 'Escape' || e.key === 'Esc') && !panel.hidden) { close(true); } });
		document.addEventListener('click', function (e) { if (!panel.hidden && !wrap.contains(e.target)) { close(false); } });

		apply();
	}

	if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', init); } else { init(); }
	window.addEventListener('storage', function (e) { if (e.key === KEY) { state = load(); apply(); } });
})();

/* Відео (YouTube без cookie, вантажиться після натискання) і фотогалерея. */
(function () {
	function ready(fn) { if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', fn); } else { fn(); } }
	ready(function () {
		document.addEventListener('click', function (e) {
			var b = e.target.closest('button.igs-video__btn[data-yt]');
			if (!b) { return; }
			if (window.matchMedia && window.matchMedia('(pointer:coarse)').matches) { window.open('https://www.youtube.com/watch?v=' + encodeURIComponent(b.getAttribute('data-yt')), '_blank', 'noopener'); return; }
			var f = document.createElement('iframe');
			f.src = 'https://www.youtube-nocookie.com/embed/' + encodeURIComponent(b.getAttribute('data-yt')) + '?autoplay=1&rel=0';
			f.title = b.getAttribute('data-title');
			f.allow = 'autoplay; encrypted-media; picture-in-picture; fullscreen';
			f.setAttribute('allowfullscreen', '');
			f.className = 'igs-video__frame';
			b.parentNode.replaceChild(f, b);
			f.focus();
		});

		var dlg = document.querySelector('.igs-lightbox');
		var links = Array.prototype.slice.call(document.querySelectorAll('.igs-photo'));
		if (!dlg || !links.length || typeof dlg.showModal !== 'function') { return; }
		var img = dlg.querySelector('img'), cap = dlg.querySelector('figcaption'), cur = 0, opener = null;
		function show(i) {
			cur = (i + links.length) % links.length;
			var th = links[cur].querySelector('img');
			img.src = links[cur].getAttribute('href');
			img.alt = th.alt;
			cap.textContent = th.alt + ' (' + (cur + 1) + ' / ' + links.length + ')';
		}
		links.forEach(function (a, i) {
			a.addEventListener('click', function (e) { e.preventDefault(); opener = a; show(i); dlg.showModal(); dlg.querySelector('.igs-lightbox__close').focus(); });
		});
		dlg.querySelector('.igs-lightbox__prev').addEventListener('click', function () { show(cur - 1); });
		dlg.querySelector('.igs-lightbox__next').addEventListener('click', function () { show(cur + 1); });
		dlg.querySelector('.igs-lightbox__close').addEventListener('click', function () { dlg.close(); });
		dlg.addEventListener('keydown', function (e) {
			if (e.key === 'ArrowLeft') { show(cur - 1); }
			if (e.key === 'ArrowRight') { show(cur + 1); }
		});
		dlg.addEventListener('click', function (e) { if (e.target === dlg) { dlg.close(); } });
		dlg.addEventListener('close', function () { img.removeAttribute('src'); if (opener) { opener.focus(); } });
	});
})();

// Кнопка «Нагору»: з’являється після прокручування на півтора екрана.
(function () {
	var b = document.querySelector('.igs-totop'); if (!b) return;
	var on = function () { b.hidden = window.scrollY < window.innerHeight * 1.5; };
	window.addEventListener('scroll', on, { passive: true }); on();
	b.addEventListener('click', function () {
		var r = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
		window.scrollTo({ top: 0, behavior: r ? 'auto' : 'smooth' });
		var m = document.getElementById('main'); if (m) { m.setAttribute('tabindex', '-1'); m.focus({ preventScroll: true }); }
	});
})();
