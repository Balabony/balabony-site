<?php
/**
 * ІГС Львів — блокова тема. Розробка: OLBO (olbo.com.ua).
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action( 'after_setup_theme', function () {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_editor_style( 'style.css' );
	load_theme_textdomain( 'igs-lvivdim' );
} );

/* ---------- Мови: українська (основна), англійська (/en/) і польська (/pl/) ---------- */

function igs_path() {
	$p = wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/', PHP_URL_PATH );
	$p = '/' . trim( (string) $p, '/' ) . '/';
	return '//' === $p ? '/' : $p;
}

function igs_lang() {
	$p = igs_path();
	if ( 0 === strpos( $p, '/en/' ) ) { return 'en'; }
	if ( 0 === strpos( $p, '/pl/' ) ) { return 'pl'; }
	return 'uk';
}
function igs_is_en() { return 'en' === igs_lang(); }
function igs_is_pl() { return 'pl' === igs_lang(); }
// Рядок трьома мовами; польська падає на англійську, якщо не задана.
function igs_t( $uk, $en, $pl = null ) {
	$l = igs_lang();
	if ( 'pl' === $l ) { return null === $pl ? $en : $pl; }
	return 'en' === $l ? $en : $uk;
}

// Відповідні сторінки: uk, en, pl (null — польської версії немає).
function igs_lang_map() {
	return array(
		array( 'uk' => '/', 'en' => '/en/', 'pl' => '/pl/' ),
		array( 'uk' => '/pro-nas/', 'en' => '/en/about/', 'pl' => '/pl/o-nas/' ),
		array( 'uk' => '/proiekty/', 'en' => '/en/projects/', 'pl' => '/pl/projekty/' ),
		array( 'uk' => '/konkursy/', 'en' => '/en/contests/', 'pl' => null ),
		array( 'uk' => '/zvitnist/', 'en' => '/en/reports/', 'pl' => '/pl/sprawozdania/' ),
		array( 'uk' => '/kontakty/', 'en' => '/en/contact/', 'pl' => '/pl/kontakt/' ),
		array( 'uk' => '/foto-video/', 'en' => '/en/photos-videos/', 'pl' => '/pl/zdjecia-i-filmy/' ),
		array( 'uk' => '/polityka-konfidentsiinosti/', 'en' => '/en/privacy/', 'pl' => '/pl/polityka-prywatnosci/' ),
		array( 'uk' => '/zakhyst-ditei/', 'en' => '/en/child-protection/', 'pl' => '/pl/ochrona-dzieci/' ),
		array( 'uk' => '/dostupnist/', 'en' => '/en/accessibility/', 'pl' => '/pl/deklaracja-dostepnosci/' ),
	);
}
function igs_lang_row() {
	$l = igs_lang(); $p = igs_path();
	foreach ( igs_lang_map() as $r ) { if ( $r[ $l ] === $p ) { return $r; } }
	return null;
}
function igs_lang_url( $to ) {
	$r = igs_lang_row();
	$home = array( 'uk' => '/', 'en' => '/en/', 'pl' => '/pl/' );
	return home_url( ( $r && $r[ $to ] ) ? $r[ $to ] : $home[ $to ] );
}
function igs_other_lang_url() { return igs_lang_url( igs_is_en() ? 'uk' : 'en' ); }

// Атрибут lang для <html>: екранні читачі мають знати мову сторінки (WCAG 3.1.1).
add_filter( 'language_attributes', function ( $out ) {
	$l = igs_lang();
	if ( 'uk' !== $l ) {
		$out = preg_replace( '/lang="[^"]*"/', 'lang="' . $l . '"', $out );
	}
	return $out;
} );

// Фавікон (якщо в налаштуваннях WordPress не задано іконку сайту).
add_action( 'wp_head', function () {
	if ( has_site_icon() ) { return; }
	echo '<link rel="icon" href="' . esc_url( get_theme_file_uri( 'assets/favicon.svg' ) ) . '" type="image/svg+xml">' . "\n";
	echo '<link rel="icon" href="' . esc_url( get_theme_file_uri( 'assets/favicon-32.png' ) ) . '" sizes="32x32" type="image/png">' . "\n";
	echo '<link rel="apple-touch-icon" href="' . esc_url( get_theme_file_uri( 'assets/apple-touch-icon.png' ) ) . '">' . "\n";
	echo '<meta name="theme-color" content="#0f1e3a">' . "\n";
}, 3 );

// hreflang для пошукових систем.
add_action( 'wp_head', function () {
	$r = igs_lang_row();
	if ( ! $r ) { return; }
	foreach ( array( 'uk', 'en', 'pl' ) as $l ) {
		if ( $r[ $l ] ) { echo '<link rel="alternate" hreflang="' . $l . '" href="' . esc_url( home_url( $r[ $l ] ) ) . '">' . "\n"; }
	}
	echo '<link rel="alternate" hreflang="x-default" href="' . esc_url( home_url( $r['uk'] ) ) . '">' . "\n";
}, 2 );

// Перемикач мов: посилання на дві інші мови.
add_shortcode( 'igs_lang', function () {
	$all = array(
		'uk' => array( 'УКР', 'українська версія сайту' ),
		'en' => array( 'EN', 'English version' ),
		'pl' => array( 'PL', 'wersja polska' ),
	);
	$out = '<span class="igs-langs">';
	foreach ( $all as $l => $t ) {
		if ( igs_lang() === $l ) { continue; }
		$out .= '<a class="igs-lang" href="' . esc_url( igs_lang_url( $l ) ) . '" hreflang="' . $l . '" lang="' . $l . '">' . $t[0] . '<span class="screen-reader-text"> — ' . $t[1] . '</span></a>';
	}
	return $out . '</span>';
} );

/* ---------- Стилі, шрифти, панель доступності ---------- */

add_action( 'wp_enqueue_scripts', function () {
	$v = wp_get_theme()->get( 'Version' );
	wp_enqueue_style( 'igs-lvivdim', get_stylesheet_uri(), array(), $v );
	wp_enqueue_script( 'igs-a11y', get_theme_file_uri( 'assets/a11y.js' ), array(), $v, array( 'strategy' => 'defer', 'in_footer' => false ) );
} );

// Застосувати збережені налаштування до першого відмальовування (без «блимання»).
add_action( 'wp_head', function () {
	echo "<script>(function(){try{var s=JSON.parse(localStorage.getItem('igs_a11y')||'{}'),d=document.documentElement;if(s.size&&s.size!=='0')d.setAttribute('data-size',s.size);if(s.theme&&s.theme!=='default')d.setAttribute('data-theme',s.theme);if(s.font&&s.font!=='default')d.setAttribute('data-font',s.font);}catch(e){}})();</script>\n";
}, 1 );

add_shortcode( 'igs_a11y', function () {
	$l  = igs_lang();
	$t  = 'pl' === $l ? array(
		'btn' => 'Dostępność', 'title' => 'Ustawienia dostępności', 'size' => 'Rozmiar tekstu',
		'theme' => 'Motyw kolorystyczny', 'th0' => 'Dzienny', 'th1' => 'Łagodny dzienny', 'th3' => 'Nocny', 'th2' => 'Wysoki kontrast', 'dn' => 'Tryb nocny',
		'font' => 'Czcionka', 'f0' => 'Standardowa', 'f1' => 'Bezszeryfowa', 'f2' => 'Dla osób z dysleksją',
		'reset' => 'Przywróć ustawienia', 'close' => 'Zamknij', 'sz' => array( -1 => 'Mniejszy', 0 => 'Standardowy rozmiar', 1 => 'Większy', 2 => 'Duży', 3 => 'Największy' ),
	) : ( 'en' === $l ? array(
		'btn' => 'Accessibility', 'title' => 'Accessibility settings', 'size' => 'Text size',
		'theme' => 'Colour theme', 'th0' => 'Day', 'th1' => 'Soft daylight', 'th3' => 'Night', 'th2' => 'High contrast', 'dn' => 'Night mode',
		'font' => 'Font', 'f0' => 'Standard', 'f1' => 'Sans-serif', 'f2' => 'Dyslexia-friendly',
		'reset' => 'Reset settings', 'close' => 'Close', 'sz' => array( -1 => 'Smaller', 0 => 'Standard size', 1 => 'Larger', 2 => 'Large', 3 => 'Largest' ),
	) : array(
		'btn' => 'Доступність', 'title' => 'Налаштування доступності', 'size' => 'Розмір тексту',
		'theme' => 'Колірна тема', 'th0' => 'Денна', 'th1' => 'Ніжна денна', 'th3' => 'Нічна', 'th2' => 'Висока контрастність', 'dn' => 'Нічний режим',
		'font' => 'Шрифт', 'f0' => 'Стандартний', 'f1' => 'Без засічок', 'f2' => 'Для людей з дислексією',
		'reset' => 'Скинути налаштування', 'close' => 'Закрити', 'sz' => array( -1 => 'Менший', 0 => 'Звичайний розмір', 1 => 'Більший', 2 => 'Великий', 3 => 'Найбільший' ),
	) );
	$icon = '<svg class="igs-a11y__icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24"><path d="M3 18 8 5l5 13M5 13.5h6" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><circle cx="18" cy="14" r="3.2" fill="none" stroke="currentColor" stroke-width="2"/><path d="M21.2 10.5V18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>';
	$sz = '';
	foreach ( $t['sz'] as $i => $label ) {
		$sz .= '<button type="button" class="igs-a11y__opt igs-a11y__sz igs-a11y__sz--' . ( $i < 0 ? 'm1' : $i ) . '" data-k="size" data-v="' . $i . '" aria-pressed="false">A<span class="screen-reader-text">: ' . esc_html( $label ) . '</span></button>';
	}
	$opt = function ( $k, $v, $label ) {
		return '<button type="button" class="igs-a11y__opt igs-a11y__opt--' . $k . '-' . $v . '" data-k="' . $k . '" data-v="' . $v . '" aria-pressed="false">' . $label . '</button>';
	};
	$dn = '<button type="button" class="igs-daynight" aria-pressed="false" aria-label="' . esc_attr( $t['dn'] ) . '">'
		. '<svg class="igs-daynight__sun" aria-hidden="true" focusable="false" viewBox="0 0 24 24"><circle cx="12" cy="12" r="4.2" fill="none" stroke="currentColor" stroke-width="2"/><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M5.3 18.7l1.6-1.6M17.1 6.9l1.6-1.6" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>'
		. '<svg class="igs-daynight__moon" aria-hidden="true" focusable="false" viewBox="0 0 24 24"><path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"/><circle cx="17" cy="5" r="1.2" fill="currentColor"/></svg>'
		. '</button>';
	return $dn . '<div class="igs-a11y">'
		. '<button type="button" class="igs-a11y__btn" aria-expanded="false" aria-controls="igs-a11y-panel">' . $icon . '<span class="igs-a11y__btnlabel">' . $t['btn'] . '</span></button>'
		. '<div class="igs-a11y__panel" id="igs-a11y-panel" role="group" aria-labelledby="igs-a11y-title" hidden>'
		. '<div class="igs-a11y__head"><p class="igs-a11y__title" id="igs-a11y-title">' . $t['title'] . '</p><button type="button" class="igs-a11y__close">' . $t['close'] . '</button></div>'
		. '<div class="igs-a11y__group" role="group" aria-labelledby="igs-a11y-g1"><p class="igs-a11y__legend" id="igs-a11y-g1">' . $t['size'] . '</p><div class="igs-a11y__row igs-a11y__row--sizes">' . $sz . '</div></div>'
		. '<div class="igs-a11y__group" role="group" aria-labelledby="igs-a11y-g2"><p class="igs-a11y__legend" id="igs-a11y-g2">' . $t['theme'] . '</p><div class="igs-a11y__row">'
		. $opt( 'theme', 'default', $t['th0'] ) . $opt( 'theme', 'soft', $t['th1'] ) . $opt( 'theme', 'night', $t['th3'] ) . $opt( 'theme', 'contrast', $t['th2'] ) . '</div></div>'
		. '<div class="igs-a11y__group" role="group" aria-labelledby="igs-a11y-g3"><p class="igs-a11y__legend" id="igs-a11y-g3">' . $t['font'] . '</p><div class="igs-a11y__row">'
		. $opt( 'font', 'default', $t['f0'] ) . $opt( 'font', 'sans', $t['f1'] ) . $opt( 'font', 'dyslexia', $t['f2'] ) . '</div></div>'
		. '<button type="button" class="igs-a11y__reset">' . $t['reset'] . '</button>'
		. '<p class="igs-a11y__status screen-reader-text" role="status" aria-live="polite"></p>'
		. '</div></div>';
} );

// Посилання «Перейти до змісту» на початку сторінки (доступність).
add_action( 'wp_body_open', function () {
	$label = igs_t( 'Перейти до змісту', 'Skip to content', 'Przejdź do treści' );
	echo '<a class="skip-link" href="#main">' . esc_html( $label ) . '</a>';
}, 1 );

// Знак OLBO у футері.
add_shortcode( 'igs_olbo', function () {
	$src   = esc_url( get_theme_file_uri( 'assets/olbo-logo.svg' ) );
	$text  = igs_t( 'Розробка:', 'Developed by:', 'Realizacja:' );
	$label = igs_t( 'Розробка: студія OLBO (відкривається в новій вкладці)', 'Developed by OLBO studio (opens in a new tab)', 'Realizacja: studio OLBO (otwiera się w nowej karcie)' );
	return '<a class="igs-olbo" href="https://olbo.com.ua/?utm_source=lvivdim&amp;utm_medium=footer&amp;utm_campaign=credit" target="_blank" rel="noopener" aria-label="' . esc_attr( $label ) . '">' . $text . ' <img src="' . $src . '" alt="" width="55" height="14"></a>';
} );

/* ---------- Фото й відео з тренінгів ---------- */

function igs_media() {
	static $m = null;
	if ( null === $m ) { $m = include get_theme_file_path( 'inc-media.php' ); }
	return $m;
}

// Відео: спершу лише обкладинка (без трекерів YouTube), плеєр вантажиться після натискання.
add_shortcode( 'igs_videos', function ( $atts ) {
	$a    = shortcode_atts( array( 'limit' => 0, 'type' => '' ), $atts );
	$en   = igs_is_en();
	$list = igs_media()['videos'];
	if ( 'int' === $a['type'] ) { $list = array_values( array_filter( $list, function ( $v ) { return ! empty( $v['int'] ); } ) ); }
	if ( 'other' === $a['type'] ) { $list = array_values( array_filter( $list, function ( $v ) { return empty( $v['int'] ); } ) ); }
	if ( (int) $a['limit'] > 0 ) { $list = array_slice( $list, 0, (int) $a['limit'] ); }
	$play = igs_t( 'Відтворити відео: ', 'Play video: ', 'Odtwórz film: ' );
	$out  = '<ul class="igs-videos">';
	foreach ( $list as $v ) {
		$t   = igs_t( $v['uk'], $v['en'], isset( $v['pl'] ) ? $v['pl'] : null );
		$id  = esc_attr( $v['id'] );
		$out .= '<li class="igs-video"><a class="igs-video__btn" href="https://www.youtube.com/watch?v=' . $id . '" target="_blank" rel="noopener">'
			. ( ! empty( $v['img'] ) ? '<img src="' . esc_url( content_url( 'uploads/igs-media/' . $v['img'] ) ) . '" alt="" loading="lazy" style="object-position:' . esc_attr( isset( $v['pos'] ) ? $v['pos'] : 'center 30%' ) . '">' : '<img src="https://i.ytimg.com/vi/' . $id . '/sddefault.jpg" onerror="this.onerror=null;this.src=\'https://i.ytimg.com/vi/' . $id . '/hqdefault.jpg\'" alt="" loading="lazy" width="640" height="480">' )
			. '<span class="igs-video__play" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M8 5.5v13l11-6.5z" fill="currentColor"/></svg></span>'
			. '<span class="screen-reader-text">' . esc_html( $play ) . '</span><span class="igs-video__title">' . esc_html( $t ) . '</span><span class="screen-reader-text"> ' . esc_html( igs_t( '(відкривається на YouTube)', '(opens on YouTube)', '(otwiera się w YouTube)' ) ) . '</span></a></li>';
	}
	return $out . '</ul>';
} );

// Фотогалерея з переглядом у вікні (клавіші ← → та Esc).
add_shortcode( 'igs_photos', function ( $atts ) {
	$a    = shortcode_atts( array( 'limit' => 0 ), $atts );
	$en   = igs_is_en();
	$list = igs_media()['photos'];
	if ( (int) $a['limit'] > 0 ) { $list = array_slice( $list, 0, (int) $a['limit'] ); }
	$base = content_url( 'uploads/igs-media/' );
	$open = igs_t( 'Відкрити фото: ', 'Open photo: ', 'Otwórz zdjęcie: ' );
	$out  = '<ul class="igs-photos">';
	foreach ( $list as $i => $p ) {
		$alt  = igs_t( $p['uk'], $p['en'], isset( $p['pl'] ) ? $p['pl'] : null );
		$out .= '<li><a class="igs-photo" href="' . esc_url( $base . $p['f'] . '.jpg' ) . '" data-i="' . (int) $i . '" aria-label="' . esc_attr( $open . $alt ) . '">'
			. '<img src="' . esc_url( $base . $p['f'] . '-720.jpg' ) . '" alt="' . esc_attr( $alt ) . '" loading="lazy" decoding="async">'
			. ( isset( $p['cap'] ) ? '<span class="igs-photo__cap" aria-hidden="true">' . esc_html( igs_t( $p['cap'][0], $p['cap'][1], isset( $p['cap'][2] ) ? $p['cap'][2] : null ) ) . '</span>' : '' ) . '</a></li>';
	}
	$t = igs_is_pl() ? array( 'dlg' => 'Przeglądanie zdjęć', 'close' => 'Zamknij', 'prev' => 'Poprzednie zdjęcie', 'next' => 'Następne zdjęcie' ) : ( $en
		? array( 'dlg' => 'Photo viewer', 'close' => 'Close', 'prev' => 'Previous photo', 'next' => 'Next photo' )
		: array( 'dlg' => 'Перегляд фото', 'close' => 'Закрити', 'prev' => 'Попереднє фото', 'next' => 'Наступне фото' ) );
	$out .= '</ul><dialog class="igs-lightbox" aria-label="' . esc_attr( $t['dlg'] ) . '">'
		. '<figure class="igs-lightbox__fig"><img alt=""><figcaption aria-live="polite"></figcaption></figure>'
		. '<button type="button" class="igs-lightbox__nav igs-lightbox__prev"><span aria-hidden="true">‹</span><span class="screen-reader-text">' . $t['prev'] . '</span></button>'
		. '<button type="button" class="igs-lightbox__nav igs-lightbox__next"><span aria-hidden="true">›</span><span class="screen-reader-text">' . $t['next'] . '</span></button>'
		. '<button type="button" class="igs-lightbox__close">' . $t['close'] . '</button></dialog>';
	return $out;
} );

/* ---------- Переадресація зі старих адрес lvivdim.com (301) ---------- */
add_action( 'template_redirect', function () {
	if ( ! is_404() ) { return; }
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ), '/' );
	$to   = '';
	if ( preg_match( '#^posts/([a-z0-9\-]+)$#', $path, $m ) ) {
		$p = get_posts( array( 'name' => $m[1], 'post_type' => 'post', 'numberposts' => 1 ) );
		$to = $p ? get_permalink( $p[0] ) : home_url( '/category/novyny/' );
	} elseif ( preg_match( '#^([a-z0-9\-]+)$#', $path, $m ) && get_posts( array( 'name' => $m[1] . '__trashed', 'post_type' => 'post', 'post_status' => 'trash', 'numberposts' => 1 ) ) ) {
		$to = home_url( '/category/novyny/' );
	} elseif ( preg_match( '#^categories/([a-z0-9\-]+)$#', $path, $m ) ) {
		$c  = get_category_by_slug( $m[1] );
		$to = $c ? get_category_link( $c ) : home_url( '/' );
	} elseif ( preg_match( '#^pages/([a-z0-9\-]+)$#', $path, $m ) ) {
		$map = array( 'pro-nas' => '/pro-nas/', 'konkursi' => '/konkursy/', 'avtori' => '/konkursy/', 'adresa' => '/kontakty/', 'pidtrymaty' => '/kontakty/', 'reklama' => '/kontakty/', 'vakansiyi' => '/category/robota/', 'navchalna-praktika' => '/pro-nas/', 'statti' => '/category/novyny/' );
		$to  = home_url( isset( $map[ $m[1] ] ) ? $map[ $m[1] ] : '/' );
	}
	if ( $to ) { wp_safe_redirect( $to, 301 ); exit; }
} );

/* ---------- SEO: опис, Open Graph, структуровані дані, robots.txt ---------- */

function igs_first_image( $post ) {
	if ( has_post_thumbnail( $post ) ) { return get_the_post_thumbnail_url( $post, 'large' ); }
	if ( preg_match( '#<img[^>]+src="([^"]+)"#', (string) $post->post_content, $m ) ) { return $m[1]; }
	return get_theme_file_uri( 'assets/igs-mark-512.png' );
}

function igs_meta_description() {
	$en = igs_is_en();
	if ( is_front_page() ) {
		return $en
			? 'Lviv NGO “Institute of Civil Society” (since 2005): accessible literature, information and civic life for people with visual impairments, veterans, displaced people and older readers across Ukraine.'
			: 'ЛОГО «Інститут громадянського суспільства» (з 2005 року): доступна література, інформація й громадське життя для людей з порушеннями зору, ветеранів, переселенців і старшого покоління по всій Україні.';
	}
	if ( is_singular() ) {
		$p = get_queried_object();
		$t = has_excerpt( $p ) ? $p->post_excerpt : $p->post_content;
		$t = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( strip_shortcodes( preg_replace( '#https?://\S+#', '', $t ) ) ) ) );
		if ( '' === $t ) { $t = get_the_title( $p ) . ' — ' . get_bloginfo( 'name' ); }
		return wp_html_excerpt( $t, 155, '…' );
	}
	if ( is_category() ) {
		$c = get_queried_object();
		return $c->description ? wp_strip_all_tags( $c->description ) : 'Матеріали рубрики «' . $c->name . '» — ЛОГО «Інститут громадянського суспільства», Львів.';
	}
	return get_bloginfo( 'description' );
}

add_action( 'wp_head', function () {
	$desc  = igs_meta_description();
	$title = wp_get_document_title();
	$url   = is_singular() ? get_permalink() : home_url( igs_path() );
	$img   = is_singular() ? igs_first_image( get_queried_object() ) : get_theme_file_uri( 'assets/igs-mark-512.png' );
	$type  = is_singular( 'post' ) ? 'article' : 'website';
	$loc   = igs_t( 'uk_UA', 'en_US', 'pl_PL' );
	echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
	echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '">' . "\n";
	echo '<meta property="og:locale" content="' . $loc . '">' . "\n";
	echo '<meta property="og:type" content="' . $type . '">' . "\n";
	echo '<meta property="og:title" content="' . esc_attr( $title ) . '">' . "\n";
	echo '<meta property="og:description" content="' . esc_attr( $desc ) . '">' . "\n";
	echo '<meta property="og:url" content="' . esc_url( $url ) . '">' . "\n";
	echo '<meta property="og:image" content="' . esc_url( $img ) . '">' . "\n";
	echo '<meta name="twitter:card" content="summary_large_image">' . "\n";

	$org = array(
		'@type' => 'NGO', '@id' => home_url( '/#org' ),
		'name' => 'Львівська обласна громадська організація «Інститут громадянського суспільства»',
		'alternateName' => array( 'ЛОГО «Інститут громадянського суспільства»', 'ІГС', 'Institute of Civil Society' ),
		'url' => home_url( '/' ), 'logo' => get_theme_file_uri( 'assets/igs-mark-512.png' ),
		'foundingDate' => '2005-11-25', 'taxID' => '33951844', 'email' => 'hello@olbo.com.ua', 'telephone' => '+380505859141',
		'address' => array( '@type' => 'PostalAddress', 'streetAddress' => 'вул. Петлюри, 51', 'addressLocality' => 'Львів', 'postalCode' => '79021', 'addressCountry' => 'UA' ),
		'areaServed' => 'UA', 'knowsLanguage' => array( 'uk', 'en', 'pl' ),
		'knowsAbout' => array( 'цифрова доступність', 'WCAG 2.1', 'інклюзія людей з порушеннями зору', 'медіаграмотність', 'література', 'підтримка ветеранів' ),
		'sameAs' => array( 'https://balabony.com' ),
	);
	$graph = array( $org, array( '@type' => 'WebSite', '@id' => home_url( '/#site' ), 'url' => home_url( '/' ), 'name' => get_bloginfo( 'name' ), 'inLanguage' => igs_lang(), 'publisher' => array( '@id' => home_url( '/#org' ) ) ) );
	if ( is_singular( 'post' ) ) {
		$p = get_queried_object(); $cats = get_the_category( $p->ID );
		$graph[] = array( '@type' => 'Article', 'headline' => get_the_title( $p ), 'description' => $desc, 'image' => $img,
			'datePublished' => get_the_date( 'c', $p ), 'dateModified' => get_the_modified_date( 'c', $p ), 'inLanguage' => 'uk',
			'mainEntityOfPage' => get_permalink( $p ), 'author' => array( '@id' => home_url( '/#org' ) ), 'publisher' => array( '@id' => home_url( '/#org' ) ),
			'articleSection' => $cats ? $cats[0]->name : null );
		$crumbs = array( array( '@type' => 'ListItem', 'position' => 1, 'name' => 'Головна', 'item' => home_url( '/' ) ) );
		if ( $cats ) { $crumbs[] = array( '@type' => 'ListItem', 'position' => 2, 'name' => $cats[0]->name, 'item' => get_category_link( $cats[0] ) ); }
		$crumbs[] = array( '@type' => 'ListItem', 'position' => count( $crumbs ) + 1, 'name' => get_the_title( $p ) );
		$graph[] = array( '@type' => 'BreadcrumbList', 'itemListElement' => $crumbs );
	}
	if ( is_page( array( 'zvitnist', 'reports', 'sprawozdania' ) ) ) {
		foreach ( array( 2024, 2025 ) as $y ) {
			$graph[] = array( '@type' => 'Report', 'name' => 'Фінансова звітність ЛОГО «Інститут громадянського суспільства» за ' . $y . ' рік',
				'inLanguage' => 'uk', 'datePublished' => ( $y + 1 ) . '-01-01', 'encodingFormat' => 'application/pdf',
				'url' => content_url( 'uploads/igs-docs/igs-finansova-zvitnist-' . $y . '.pdf' ),
				'thumbnailUrl' => content_url( 'uploads/igs-docs/igs-finansova-zvitnist-' . $y . '-cover.jpg' ),
				'author' => array( '@id' => home_url( '/#org' ) ), 'publisher' => array( '@id' => home_url( '/#org' ) ) );
		}
	}
	echo '<script type="application/ld+json">' . wp_json_encode( array( '@context' => 'https://schema.org', '@graph' => $graph ), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
}, 4 );

// robots.txt: дозволяємо пошуковикам і ШІ-сервісам, вказуємо карту сайту та llms.txt.
add_filter( 'robots_txt', function ( $out, $public ) {
	if ( ! $public ) { return $out; }
	$bots = array( 'GPTBot', 'OAI-SearchBot', 'ChatGPT-User', 'ClaudeBot', 'Claude-User', 'Claude-SearchBot', 'PerplexityBot', 'Google-Extended', 'Applebot-Extended' );
	foreach ( $bots as $b ) { $out .= "\nUser-agent: $b\nAllow: /\n"; }
	$out .= "\n# Короткий опис сайту для ШІ: " . home_url( '/llms.txt' ) . "\n";
	return $out;
}, 10, 2 );

// llms.txt — стислий опис організації й головних сторінок для ШІ-асистентів.
add_action( 'init', function () {
	add_rewrite_rule( '^llms\.txt$', 'index.php?igs_llms=1', 'top' );
} );
add_filter( 'query_vars', function ( $v ) { $v[] = 'igs_llms'; return $v; } );
add_action( 'template_redirect', function () {
	if ( ! get_query_var( 'igs_llms' ) ) { return; }
	header( 'Content-Type: text/plain; charset=utf-8' );
	$h = home_url();
	echo "# ЛОГО «Інститут громадянського суспільства» (Institute of Civil Society), Львів\n\n";
	echo "> Громадська організація з 2005 року (ЄДРПОУ 33951844, неприбуткова, ознака 0032). Робимо літературу, інформацію й громадське життя доступними для людей з порушеннями зору, ветеранів, переселенців і старшого покоління по всій Україні. Розвиваємо літературну платформу «Балабони», проводимо літературні конкурси, тренінги з медіаграмотності й цифрової доступності (WCAG 2.1), навчальну практику для студентів-журналістів.\n\n";
	echo "## Головне\n- [Про нас: місія, завдання, управління, реквізити]($h/pro-nas/)\n- [Проєкти]($h/proiekty/)\n- [Конкурси]($h/konkursy/)\n- [Звітність і фінансова історія]($h/zvitnist/)\n- [Фото й відео з тренінгів]($h/foto-video/)\n- [Контакти]($h/kontakty/)\n\n";
	echo "## Polski\n- [O nas]($h/pl/o-nas/)\n- [Projekty]($h/pl/projekty/)\n- [Sprawozdania]($h/pl/sprawozdania/)\n- [Kontakt]($h/pl/kontakt/)\n\n";
	echo "## English\n- [About us]($h/en/about/)\n- [Projects]($h/en/projects/)\n- [Reports]($h/en/reports/)\n- [Contact]($h/en/contact/)\n\n";
	echo "## Документи\n- [Фінансова звітність 2024 (PDF)]($h/wp-content/uploads/igs-docs/igs-finansova-zvitnist-2024.pdf)\n- [Фінансова звітність 2025 (PDF)]($h/wp-content/uploads/igs-docs/igs-finansova-zvitnist-2025.pdf)\n\n";
	echo "## Матеріали\n";
	foreach ( get_posts( array( 'numberposts' => 40, 'post_status' => 'publish' ) ) as $p ) { echo '- [' . get_the_title( $p ) . '](' . get_permalink( $p ) . ")\n"; }
	exit;
} );

/* ---------- Перелінковка: рубрика й схожі матеріали на сторінці статті ---------- */
add_shortcode( 'igs_cat', function () {
	$c = get_the_category();
	if ( ! $c ) { return '<a href="/category/novyny/">Новини</a>'; }
	return '<a href="' . esc_url( get_category_link( $c[0] ) ) . '">' . esc_html( $c[0]->name ) . '</a>';
} );
add_shortcode( 'igs_related', function () {
	$id = get_the_ID(); $c = wp_get_post_categories( $id );
	$ps = get_posts( array( 'numberposts' => 3, 'post__not_in' => array( $id ), 'category__in' => $c, 'orderby' => 'date' ) );
	if ( count( $ps ) < 3 ) { $ps = array_merge( $ps, get_posts( array( 'numberposts' => 3 - count( $ps ), 'post__not_in' => array_merge( array( $id ), wp_list_pluck( $ps, 'ID' ) ) ) ) ); }
	if ( ! $ps ) { return ''; }
	$o = '<aside class="igs-related" aria-labelledby="igs-rel-h"><h2 id="igs-rel-h">Читайте також</h2><ul>';
	foreach ( $ps as $p ) { $o .= '<li><a href="' . esc_url( get_permalink( $p ) ) . '">' . esc_html( get_the_title( $p ) ) . '</a><span>' . esc_html( get_the_date( 'd.m.Y', $p ) ) . '</span></li>'; }
	return $o . '</ul></aside>';
} );

// Клас сторінки за слагом — для фонових фото в шапці сторінок.
add_filter( 'body_class', function ( $c ) {
	if ( is_page() ) { $c[] = 'igs-page-' . get_post_field( 'post_name', get_queried_object_id() ); }
	return $c;
} );

/* ---------- Перелінковка: тематичні посилання під статтею ---------- */
add_shortcode( 'igs_more', function () {
	$c = wp_get_post_categories( get_the_ID(), array( 'fields' => 'slugs' ) );
	$t = strtolower( get_the_title() . ' ' . wp_strip_all_tags( get_the_content() ) );
	$links = array();
	if ( preg_match( '/тренінг|переселен|впо|винник/u', $t ) ) { $links['/foto-video/'] = 'Фото й відео з тренінгів для дітей-переселенців'; $links['/proiekty/'] = 'Наші проєкти'; }
	if ( preg_match( '/конкурс|автор|оповідан|казк|балабон/u', $t ) ) { $links['/konkursy/'] = 'Літературні конкурси'; $links['https://balabony.com'] = 'Платформа «Балабони»'; }
	if ( preg_match( '/незряч|утос|доступн|wcag/u', $t ) ) { $links['/proiekty/'] = 'Проєкти з доступності'; }
	if ( preg_match( '/грант|донор|uCare|партнер/ui', $t ) ) { $links['/zvitnist/'] = 'Звітність і фінансова історія'; }
	if ( preg_match( '/практик|студент|журналіст/u', $t ) ) { $links['/praktyka/'] = 'Практика для молодих журналістів'; }
	if ( count( $links ) < 2 ) { $links['/pro-nas/'] = 'Про Інститут громадянського суспільства'; $links['/proiekty/'] = 'Наші проєкти'; }
	$links['/kontakty/'] = 'Співпраця та підтримка';
	$o = '<nav class="igs-more" aria-label="Корисні розділи"><p class="igs-more__h">Більше на сайті</p><ul>';
	foreach ( array_slice( $links, 0, 4, true ) as $u => $l ) { $o .= '<li><a href="' . esc_url( $u ) . '">' . esc_html( $l ) . '</a></li>'; }
	return $o . '</ul></nav>';
} );

// Карта сайту: без сторінок авторів, з датами оновлення.
add_filter( 'wp_sitemaps_add_provider', function ( $provider, $name ) { return 'users' === $name ? false : $provider; }, 10, 2 );
add_filter( 'wp_sitemaps_taxonomies', function ( $t ) { unset( $t['post_tag'], $t['post_format'] ); return $t; } );
add_filter( 'wp_sitemaps_posts_entry', function ( $e, $p ) { $e['lastmod'] = get_post_modified_time( 'c', true, $p ); return $e; }, 10, 2 );

/* ---------- Історія організації: стрічка подій (uk/en/pl) ---------- */
add_shortcode( 'igs_history', function () {
	$rows = array(
		array( '2005', '2005', '2005',
			'Початок: газета «Життя»', 'The beginning: the newspaper “Zhyttia”', 'Początek: gazeta „Żyttia”',
			'Реєструємо громадську організацію. Усе починається зі щотижневої газети «Життя», де друкуємо справжні історії читачів.',
			'We register the organisation. It all starts with the weekly newspaper “Zhyttia”, which publishes real stories from its readers.',
			'Rejestrujemy organizację. Wszystko zaczyna się od tygodnika „Żyttia”, w którym publikujemy prawdziwe historie czytelników.' ),
		array( 'Щороку', 'Every year', 'Co roku',
			'Конкурси для дітей', 'Contests for children', 'Konkursy dla dzieci',
			'Щорічні творчі конкурси для дітей і школярів.',
			'Annual creative contests for children and schoolchildren.',
			'Coroczne konkursy twórcze dla dzieci i uczniów.' ),
		array( 'Щороку', 'Every year', 'Co roku',
			'Конкурси для читачів і письменників', 'Contests for readers and writers', 'Konkursy dla czytelników i pisarzy',
			'Літературні конкурси для дорослих авторів і аматорів. Найкращі твори публікуємо.',
			'Literary contests for adult and amateur writers. We publish the best works.',
			'Konkursy literackie dla dorosłych autorów i amatorów. Najlepsze utwory publikujemy.' ),
		array( 'Що два роки', 'Every two years', 'Co dwa lata',
			'Навчання для учнів шкіл', 'Training for schoolchildren', 'Szkolenia dla uczniów',
			'Тренінги для дітей і учнів шкіл: медіаграмотність, творче письмо, критичне мислення.',
			'Training for children and schoolchildren: media literacy, creative writing, critical thinking.',
			'Szkolenia dla dzieci i uczniów: edukacja medialna, kreatywne pisanie, krytyczne myślenie.' ),
		array( 'З 2020', 'Since 2020', 'Od 2020',
			'Практика для студентів', 'Internships for students', 'Praktyki dla studentów',
			'Щороку студенти проходять у нашій редакції навчальну практику.',
			'Every year students do their internships in our newsroom.',
			'Co roku studenci odbywają praktyki w naszej redakcji.' ),
		array( '2023', '2023', '2023',
			'Активна грантова діяльність', 'Active grant work', 'Aktywna działalność grantowa',
			'Реалізуємо проєкти за підтримки донорів: тренінги для дітей-переселенців у Винниках. Долучаємося до Google for Nonprofits.',
			'We run donor-funded projects, including training for internally displaced children in Vynnyky, and join Google for Nonprofits.',
			'Realizujemy projekty wspierane przez darczyńców, m.in. szkolenia dla dzieci przesiedlonych w Wynnykach, i dołączamy do Google for Nonprofits.' ),
		array( '2026', '2026', '2026',
			'Платформа «Балабони»', 'The Balabony platform', 'Platforma „Bałabony”',
			'Запускаємо літературну платформу «Балабони»: понад 1150 творів і 140 авторів. Грант uCare, ElevenLabs Impact Program, озвучення творів голосами авторів.',
			'We launch the Balabony literary platform: over 1,150 works by 140+ authors. A uCare grant, the ElevenLabs Impact Program and audio versions in the authors’ own voices.',
			'Uruchamiamy platformę literacką „Bałabony”: ponad 1150 utworów i 140 autorów. Grant uCare, ElevenLabs Impact Program i nagrania głosami autorów.' ),
		array( 'Сьогодні', 'Today', 'Dziś',
			'Три газети по всій Україні', 'Three newspapers across Ukraine', 'Trzy gazety w całej Ukrainie',
			'Літературні газети «Життя», «Життя. Історії» та «Життєві історії» читають по всій Україні завдяки Укрпошті. Співпрацюємо з УТОС, залучаємо ветеранів.',
			'The literary newspapers “Zhyttia”, “Zhyttia. Istorii” and “Zhyttievi istorii” reach readers all over Ukraine through Ukrposhta. We work with the Ukrainian Association of the Blind and involve veterans.',
			'Gazety literackie „Żyttia”, „Żyttia. Istoriji” i „Żyttiewi istoriji” trafiają do czytelników w całej Ukrainie dzięki Ukrposzcie. Współpracujemy ze Stowarzyszeniem Niewidomych i angażujemy weteranów.' ),
	);
	$o = '<section class="igs-history" aria-labelledby="igs-hist-h"><h2 id="igs-hist-h">' . esc_html( igs_t( 'Наша історія', 'Our story', 'Nasza historia' ) ) . '</h2><ol class="igs-history__list">';
	foreach ( $rows as $r ) {
		$o .= '<li><span class="igs-history__when">' . esc_html( igs_t( $r[0], $r[1], $r[2] ) ) . '</span><div><p class="igs-history__t">' . esc_html( igs_t( $r[3], $r[4], $r[5] ) ) . '</p><p class="igs-history__d">' . esc_html( igs_t( $r[6], $r[7], $r[8] ) ) . '</p></div></li>';
	}
	return $o . '</ol></section>';
} );

// 10.11.2026: прибираємо другий, стандартний «Перейти до вмісту» (є власний, трьома мовами),
// стрічку коментарів і — на EN/PL — україномовну RSS-стрічку в <head>.
add_action( 'after_setup_theme', function () {
	remove_action( 'wp_enqueue_scripts', 'wp_enqueue_block_template_skip_link' );
	remove_action( 'wp_footer', 'the_block_template_skip_link' );
}, 20 );
add_filter( 'feed_links_show_comments_feed', '__return_false' );
add_action( 'wp', function () { if ( 'uk' !== igs_lang() ) { remove_action( 'wp_head', 'feed_links', 2 ); remove_action( 'wp_head', 'feed_links_extra', 3 ); } } );

/* ---------- Кнопка «Нагору» і перехід між статтями ---------- */
add_action( 'wp_footer', function () {
	$l = igs_t( 'Нагору', 'Back to top', 'Do góry' );
	echo '<button type="button" class="igs-totop" aria-label="' . esc_attr( $l ) . '" title="' . esc_attr( $l ) . '" hidden><svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" focusable="false"><path d="M12 19V6M6 11.5 12 5.5l6 6" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>';
} );
add_shortcode( 'igs_prevnext', function () {
	$p = get_previous_post(); $n = get_next_post();
	if ( ! $p && ! $n ) { return ''; }
	$arr = function ( $d ) { return '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false"><path d="' . ( 'l' === $d ? 'M19 12H6m5.5-6L5.5 12l6 6' : 'M5 12h13m-5.5-6 6 6-6 6' ) . '" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>'; };
	$o = '<nav class="igs-pn" aria-label="Інші статті">';
	$o .= $p ? '<a class="igs-pn__prev" href="' . esc_url( get_permalink( $p ) ) . '" rel="prev"><span class="igs-pn__k">' . $arr( 'l' ) . 'Попередня</span><span class="igs-pn__t">' . esc_html( get_the_title( $p ) ) . '</span></a>' : '<span></span>';
	$o .= $n ? '<a class="igs-pn__next" href="' . esc_url( get_permalink( $n ) ) . '" rel="next"><span class="igs-pn__k">Наступна' . $arr( 'r' ) . '</span><span class="igs-pn__t">' . esc_html( get_the_title( $n ) ) . '</span></a>' : '<span></span>';
	return $o . '</nav>';
} );

/* ---------- IndexNow: нові й оновлені сторінки одразу повідомляємо Bing/Яндексу ---------- */
define( 'IGS_INDEXNOW_KEY', '7961b6ef89731b3152b9d9c9ed087c1b' );
add_action( 'transition_post_status', function ( $new, $old, $post ) {
	if ( 'publish' !== $new || ! in_array( $post->post_type, array( 'post', 'page' ), true ) || wp_is_post_revision( $post ) ) { return; }
	$url = get_permalink( $post ); if ( ! $url ) { return; }
	wp_remote_post( 'https://api.indexnow.org/indexnow', array(
		'blocking' => false, 'timeout' => 3,
		'headers'  => array( 'Content-Type' => 'application/json; charset=utf-8' ),
		'body'     => wp_json_encode( array( 'host' => 'lvivdim.com', 'key' => IGS_INDEXNOW_KEY, 'keyLocation' => 'https://lvivdim.com/' . IGS_INDEXNOW_KEY . '.txt', 'urlList' => array( $url ) ) ),
	) );
}, 10, 3 );
